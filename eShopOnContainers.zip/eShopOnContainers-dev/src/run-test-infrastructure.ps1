docker-compose -f .\docker-compose-tests.yml -f .\docker-compose-tests.override.yml up sql-data-test nosql-data-test basket-data-test rabbitmq-test identity-api-test payment-api-test
