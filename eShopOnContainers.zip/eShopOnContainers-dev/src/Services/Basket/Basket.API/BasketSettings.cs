﻿namespace Microsoft.eShopOnContainers.Services.Basket.API;

public class BasketSettings
{
    public string ConnectionString { get; set; }
}

