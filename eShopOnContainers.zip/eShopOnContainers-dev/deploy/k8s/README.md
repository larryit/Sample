# Kubernetes deployment

This folder contains the files required to deploy eShopOnContainers to a Kubernetes cluster.

For more information see the following articles in the [wiki](  /wiki):

- [Deploy to Local Kubernetes](  /wiki/Deploy-to-Local-Kubernetes)
- [Deploy to Azure Kubernetes Service (AKS)](  /wiki/Deploy-to-Azure-Kubernetes-Service-(AKS))
